package com.example.myapplication.saathi

data class UploadImg(
    val success: Boolean,
    val message: String
)
