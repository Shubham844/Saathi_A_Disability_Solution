package com.example.myapplication.saathi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class OtpActivity : AppCompatActivity() {

    lateinit var edit_text4 : EditText
    lateinit var edit_text5 : EditText
    lateinit var edit_text6 : EditText
    lateinit var edit_text7 : EditText
    lateinit var button_two : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)

        edit_text4 = findViewById(R.id.edit_text4)
        edit_text5 = findViewById(R.id.edit_text5)
        edit_text6 = findViewById(R.id.edit_text6)
        edit_text7 = findViewById(R.id.edit_text7)
        button_two = findViewById(R.id.button_two)

        button_two.setOnClickListener {
            val intent = Intent(this,RatePlace::class.java)
            startActivity(intent)
        }
    }
}