package com.example.myapplication.saathi

import android.annotation.SuppressLint
import java.io.File
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class RatePlace : AppCompatActivity() {

    lateinit var ratingBar: RatingBar
    lateinit var editReview: EditText
    lateinit var button_three: Button

    private val IMAGE_PICK_REQUEST_CODE = 100

    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {

                val setimage = findViewById<ImageView>(R.id.imageView2)

//                setimage.setImageResource()

//                val selectedImageUri = result.data?.data
//
//                if (selectedImageUri != null) {
//                    uploadImage(selectedImageUri)
//                }
            }
        }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rate_place)

        ratingBar = findViewById(R.id.ratingBar)
        editReview = findViewById(R.id.editReview)
        button_three = findViewById(R.id.button_three)

        button_three.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//            imagePickerLauncher.launch(intent)
            startActivityForResult(intent,101)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode==101 && resultCode == RESULT_OK){
            val setimage = findViewById<ImageView>(R.id.imageView2)
            setimage.setImageURI(data?.data)
        }

    }

    private fun uploadImage(imageUri: Uri) {
        val retrofit = Retrofit.Builder()
            .baseUrl("YOUR_SERVER_BASE_URL") // Replace with your server URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)
        val imageFile = File(getRealPathFromURI(imageUri))
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), imageFile)
        val imagePart = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)
        val rating = ratingBar.rating
        val review = editReview.text.toString()
        val ratingPart = RequestBody.create("text/plain".toMediaTypeOrNull(), rating.toString())
        val reviewPart = RequestBody.create("text/plain".toMediaTypeOrNull(), review)

        val call = apiService.uploadImageWithRatingReview(imagePart, ratingPart, reviewPart)
        call.enqueue(object : Callback<UploadImg> {
            override fun onResponse(call: Call<UploadImg>, response: Response<UploadImg>) {
                if (response.isSuccessful) {
                    val uploadResponse = response.body()
                    Toast.makeText(
                        applicationContext,
                        "Image Uploaded Successfully",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(applicationContext, "Upload failed", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<UploadImg>, t: Throwable) {
                Toast.makeText(applicationContext, "Upload failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun getRealPathFromURI(uri: Uri): String {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = contentResolver.query(uri, projection, null, null, null)
        cursor?.use {
            val columnIndex = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            it.moveToFirst()
            return it.getString(columnIndex)
        }
        return uri.path ?: ""
    }
}

//unresolved refernce api error aa rha tha
