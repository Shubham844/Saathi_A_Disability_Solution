package com.example.myapplication.saathi

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

lateinit var Navigation_View:NavigationView;
lateinit var drawer_layout:DrawerLayout;

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

  Navigation_View= findViewById(R.id.Navigation_View)
       drawer_layout = findViewById(R.id.drawer_layout)

        val toggle = ActionBarDrawerToggle(
            this, drawer_layout, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer_layout.addDrawerListener(toggle)
        toggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

      //  Navigation_View.setNavigationItemSelectedListener { menuItem ->
       //     when (menuItem.itemId) {
      //          R.id.nav_item1 -> {
                    // Handle item 1 click, open the corresponding fragment, etc.
                    // supportFragmentManager.beginTransaction().replace(R.id.fragment_container, YourFragment()).commit()
       //         }
        //        R.id.nav_item2 -> {
                    // Handle item 2 click
              //  }
                // Add more cases for other menu items
           // }

           // drawer_layout.closeDrawer(GravityCompat.START)
           // true
       // }
  //  }
    }
}

fun onBackPressed() {
    if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
        drawer_layout.closeDrawer(GravityCompat.START)
    } else {
        super.onBackPressed()
    }
}